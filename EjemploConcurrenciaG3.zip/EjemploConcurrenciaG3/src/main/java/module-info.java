module ni.uam.edu.ejemploconcurrenciag3 {
    requires javafx.controls;
    requires javafx.fxml;


    opens ni.uam.edu.ejemploconcurrenciag3 to javafx.fxml;
    exports ni.uam.edu.ejemploconcurrenciag3;
}